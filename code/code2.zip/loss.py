# system lib
import argparse
import os
import shutil
import time
import random
import pdb
import numpy as np
from scipy.stats import beta

# pytorch lib
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
import torch.utils.data
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torchvision.models as models
import torch.nn.functional as F
from torch.autograd import Function

def GaussianKernel(radius, std):
    """
    Generate a gaussian blur kernel based on the given radius and std.

    Args
    ----------
    radius: int
        Radius of the Gaussian kernel. Center not included.
    std: float
        Standard deviation of the Gaussian kernel.

    Returns
    ----------
    weight: torch.FloatTensor, [2 * radius + 1, 2 * radius + 1]
        Output Gaussian kernel.

    """
    size = 2 * radius + 1
    weight = torch.ones(size, size)
    weight.requires_grad = False
    for i in range(-radius, radius+1):
        for j in range(-radius, radius+1):
            dis = (i * i) + (j * j)
            weight[i+radius][j+radius] =  np.exp(-dis / (2 * std * std))
    weight = weight / weight.sum()
    return weight

# Beta CDF with gradient
class betaCDF(Function):

    @staticmethod
    def forward(ctx, xi, a=0.6, b=0.4):
        """
        Forward function of Beta CDF.

        Args
        ----------
        xi: torch.cuda.FloatTensor
            Input tensor.
        a, b: float
            The parameter of the Beta distribution.

        Returns
        ----------
        output: torch.cuda.FloatTensor
            Output tensor.

        """
        # cast to cpu
        xi_np = xi.data.cpu().numpy()

        # compute the cdf
        output = beta.cdf(xi_np, a, b)

        # cast to gpu
        output = torch.tensor(output).float().cuda()

        # save the input
        ctx.save_for_backward(xi)
        ctx.a = a
        ctx.b = b
        return output

    @staticmethod
    def backward(ctx, grad_output):
        """
        Backward function of Beta CDF.

        Args
        ----------
        grad_output: torch.cuda.FloatTensor
            Gradient backwarded from bottom layer.

        Returns
        ----------
        grad_input: torch.cuda.FloatTensor
            Gradient backwarded to upper layer.

        """
        grad_input = None

        # load the input
        inputs = ctx.saved_tensors[0]
        a = ctx.a
        b = ctx.b
        xi = inputs.cpu().numpy()

        # compute the grad for the cdf function
        grad_b = beta.pdf(xi, a, b)

        # clip the gradient within [-1, 1]
        grad_input = torch.tensor(grad_b).float().cuda().clamp_(min=-1, max=1) * grad_output
        return grad_input, None, None

# apply the layer
beta_cdf = betaCDF.apply

def ShapingLoss_CM(assign, radius, std, num_parts, params):
    """
    Shaping loss with Cramér–von Mises criterion for Beta distribution.

    Args
    ----------
    assign: torch.cuda.FloatTensor, [batch_size, num_parts, height, width]
        Assignment map for grouping.
    radius: int
        Radius for the Gaussian kernel. 
    std: float
        Standard deviation for the Gaussian kernel.
    num_parts: int
        Number of object parts in the current model.
    alpha, beta: float
        Parameters of Beta distribution.

    Returns
    ----------
    loss: torch.cuda.FloatTensor, [1, ]
        Average batch shaping loss for the current minibatch.

    """
    batch_size = assign.shape[0]
    alpha, beta = params

    # generate the Gaussian kernel and blur the assignment maps
    if radius == 0:
        assign_smooth = assign
    else:
        weight = GaussianKernel(radius, std)
        weight = weight.contiguous().view(1, 1, 2*radius+1, 2*radius+1).expand(num_parts, 1, 2*radius+1, 2*radius+1).cuda()
        assign_smooth = torch.nn.functional.conv2d(assign, weight, groups=num_parts)

    # pool the assignment maps into [batch_size, num_parts] and sort along the first ascendingly
    assign_loss = torch.nn.functional.adaptive_max_pool2d(assign_smooth, (1,1)).squeeze(2).squeeze(2)
    assign_indicator, _ = assign_loss.sort(dim=0, descending=False)

    # clip the assignment map within [min_clamp, max_clamp] for robustness
    min_clamp = 1e-6
    max_clamp = 1-1e-6
    assign_indicator.clamp_(min=min_clamp, max=max_clamp)

    # calculate the prior CDF value for each sample
    cdf_out = beta_cdf(assign_indicator, alpha, beta)

    # computing the loss
    grid_points = torch.arange(1., batch_size+1, 1.).float().cuda() / (batch_size + 1)
    subtract_term = grid_points.view(batch_size, 1).expand_as(cdf_out)
    output_nk = (subtract_term - cdf_out) * (subtract_term - cdf_out)

    # convert from [batch_size, num_parts] into [1, ] by taking the average
    loss = output_nk.mean()
    return loss

def ShapingLoss_W(assign, radius, std, num_parts, params):
    """
    Wasserstein shaping loss for Bernoulli distribution.

    Args
    ----------
    assign: torch.cuda.FloatTensor, [batch_size, num_parts, height, width]
        Assignment map for grouping.
    radius: int
        Radius for the Gaussian kernel. 
    std: float
        Standard deviation for the Gaussian kernel.
    num_parts: int
        Number of object parts in the current model.
    p: float
        Parameter of Bernoulli distribution.

    Returns
    ----------
    loss: torch.cuda.FloatTensor, [1, ]
        Average Wasserstein shaping loss for the current minibatch.
        
    """

    p, reparam = params
    batch_size = assign.shape[0]

    # Gaussian blur
    if radius == 0:
        assign_smooth = assign
    else:
        weight = GaussianKernel(radius, std)
        weight = weight.contiguous().view(1, 1, 2*radius+1, 2*radius+1).expand(num_parts, 1, 2*radius+1, 2*radius+1).cuda()
        assign_smooth = torch.nn.functional.conv2d(assign, weight, groups=num_parts)

    # pool the assignment maps into [batch_size, num_parts] and sort along the first ascendingly
    assign_loss = torch.nn.functional.adaptive_max_pool2d(assign_smooth, (1,1)).squeeze(2).squeeze(2)
    assign_indicator, _ = assign_loss.sort(dim=0, descending=False)
    

    # generate the samples for prior according to the parameter p
    num_ones = int(p * batch_size)
    num_zeros = batch_size - num_ones
    if p != 0 and p != 1:
        subtract_matrix_zeros = torch.zeros(num_zeros, assign_indicator.shape[1]).cuda()
        subtract_matrix_ones = torch.ones(num_ones, assign_indicator.shape[1]).cuda()
        subtract_term = torch.cat([subtract_matrix_zeros, subtract_matrix_ones], dim=0)
    elif p == 0:
        subtract_term = torch.zeros(batch_size, assign_indicator.shape[1]).cuda()
    else:
        subtract_term = torch.ones(batch_size, assign_indicator.shape[1]).cuda()

    # reparameterize the distribution if specified
    if reparam == True:
        assign_indicator = (assign_indicator + 1e-5).log()
        subtract_term = (subtract_term + 1e-5).log()

    # calculate the loss
    output_nk = (subtract_term - assign_indicator).abs()
    loss = output_nk.mean()
    return loss

