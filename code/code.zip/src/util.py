import torch
import torch.nn as nn
import torch.nn.init as init
import torch.nn.functional as F
import torch.autograd as autograd
from loss import ShapingLoss, Entropy, ShapingLoss_thres

MSE_loss = nn.MSELoss().cuda()

class DeterministicConditional(nn.Module):
    def __init__(self, mapping, feat_mapping, att_mapping, img_mapping, num_parts=2, shift=None):
        """ A deterministic conditional mapping. Used as an encoder or a generator.

        Args:
            mapping: An nn.Sequential module that maps the input to the output deterministically.
            shift: A pixel-wise shift added to the output of mapping. Default: None
        """
        super().__init__()

        self.mapping = mapping
        self.feat_mapping = feat_mapping
        self.img_mapping = img_mapping
        self.att_mapping = att_mapping
        self.shift = shift
        self.nparts = num_parts

    def set_shift(self, value):
        if self.shift is None:
            return
        assert list(self.shift.data.size()) == list(value.size())
        self.shift.data = value

    def forward(self, input, temp=1, complex_=False):
        output = []
        attention = []
        for i in range(self.nparts):
            current_result = input[:, i]#current_result = self.mapping[i](input[:, i])
            current_output = self.feat_mapping[i](current_result).unsqueeze(1)#current_result[:, :3].unsqueeze(1)
            current_att = self.att_mapping[i](current_result)#current_result[:, -1].unsqueeze(1)
            output.append(current_output)
            attention.append(current_att)
        all_att = torch.cat(attention, dim=1)
        # if complex_ is True:
        #     final_att = torch.nn.functional.normalize(all_att**temp, dim=1, p=1)
        # else:
        final_att = torch.nn.functional.softmax(all_att, dim=1)
        #print(1, final_att.shape, flush=True)
        all_output = torch.cat(output, dim=1)
        #print(2, all_output.shape, flush=True)
        final_output = all_att.unsqueeze(2) * all_output
        final_output = torch.sum(final_output, dim=1)
        final_output = self.img_mapping(final_output)
        #print(3, final_output.shape, flush=True)
        if self.shift is not None:
            final_output = final_output + self.shift
        return final_output, final_att


class JointCritic(nn.Module):
    def __init__(self, x_mapping, joint_mapping, z_mapping):
        """ A joint Wasserstein critic function.

        Args:
            x_mapping: An nn.Sequential module that processes x.
        """
        super().__init__()

        self.x_net = x_mapping
        self.joint_net = joint_mapping
        self.z_net = z_mapping

    def forward(self, x):
        if self.z_net is None:
            output = self.x_net(x)
            return output
        else:
            featmap = self.joint_net(x)
            regress_z = self.z_net(featmap)
            output = self.x_net(featmap)
            return output, regress_z


class WALI(nn.Module):
    def __init__(self, G, C, args):
        """ W-GAN.

        Args:
            G: Generator p(x|z).
            C: Wasserstein critic function f(x).
        """
        super().__init__()

        self.G = G
        self.C = C
        self.args = args

    def get_generator_parameters(self):
        return self.G.parameters()

    def get_critic_parameters(self):
        return self.C.parameters()

    def generate(self, z, temper=1, complexity=False):
        return self.G(z, temp=temper, complex_=complexity)

    def criticize(self, x, x_tilde):
        input_x = torch.cat((x, x_tilde), dim=0)
        if self.args.complex is True:
            output, regress_z = self.C(input_x)
            output_z = regress_z[x.size(0):]
        else:
            output = self.C(input_x)
        data_preds, sample_preds = output[:x.size(0)], output[x.size(0):]
        # data_preds = self.C(x)
        # sample_preds = self.C(x_tilde)
        if self.args.complex is True:
            return data_preds, sample_preds, output_z
        else:
            return data_preds, sample_preds

    def calculate_grad_penalty(self, x, x_tilde):
        bsize = x.size(0)
        eps = torch.rand(bsize, 1, 1, 1).to(x.device) # eps ~ Unif[0, 1]
        intp_x = eps * x + (1 - eps) * x_tilde
        intp_x.requires_grad = True
        if self.args.complex:
            C_intp = self.C(intp_x)[0]
        else:
            C_intp = self.C(intp_x)
        grads = autograd.grad(C_intp, intp_x, grad_outputs=torch.ones(C_intp.size()).cuda(), retain_graph=True, create_graph=True, only_inputs=True)
        grads = grads[0].view(bsize, -1)
        grad_penalty = ((grads.norm(2, dim=1) - 1) ** 2).mean()
        return grad_penalty

    def forward(self, x, z, lamb=10):
        x_tilde, attention = self.generate(z, temper=self.args.temp, complexity=self.args.complex)
        att_loss = ShapingLoss(attention, self.args.radius, self.args.std, self.args.nparts, [self.args.prob, self.args.log])
        thres_loss = ShapingLoss_thres(attention, self.args.radius, self.args.std, self.args.nparts, self.args.thres)
        att_loss = self.args.coeff * att_loss + self.args.ent * Entropy(attention) + self.args.cot * thres_loss
        #print(4, x.shape, x_tilde.shape, flush=True)
        if self.args.complex is True:
            batch_size = z.shape[0]
            data_preds, sample_preds, z_regressed = self.criticize(x, x_tilde)
            regress_loss = self.args.temp * MSE_loss(z_regressed.view(batch_size, -1), z.view(batch_size, -1))
            G_loss = -torch.mean(sample_preds - data_preds)# + 1e-2 * ShapingLoss(attention, self.args.radius, self.args.std, self.args.nparts, [self.args.prob, False])
            C_loss = -G_loss + lamb * self.calculate_grad_penalty(x.data, x_tilde.data)
            return C_loss, G_loss, att_loss, regress_loss
        else:
            data_preds, sample_preds = self.criticize(x, x_tilde)
            G_loss = -torch.mean(sample_preds - data_preds)# + 1e-2 * ShapingLoss(attention, self.args.radius, self.args.std, self.args.nparts, [self.args.prob, False])
            C_loss = -G_loss + lamb * self.calculate_grad_penalty(x.data, x_tilde.data)
            return C_loss, G_loss, att_loss