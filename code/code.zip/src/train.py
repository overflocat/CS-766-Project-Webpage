# system lib
import argparse
import os
import shutil
import time
import random
import pdb
import numpy as np
import json
from PIL import Image
import colorsys

import torch
import torch.nn as nn
import torch.backends.cudnn as cudnn
import matplotlib.pyplot as plt
from torch.optim import Adam
from torch.utils import data
from torch.nn import Conv2d, ConvTranspose2d, BatchNorm2d, LeakyReLU, ReLU, Tanh
from util import DeterministicConditional, JointCritic, WALI
from torchvision import datasets, transforms, utils
from torch.utils.tensorboard import SummaryWriter


cudnn.benchmark = True
torch.manual_seed(1)
torch.cuda.manual_seed_all(1)

# arguments
parser = argparse.ArgumentParser(description='Training config')
parser.add_argument('--root', default='../', type=str, help='root directory')
parser.add_argument('--resume', help='resume path', action='store_true')
parser.add_argument('--log', help='log reparam', action='store_true')
parser.add_argument('--complex', help='use complicated arch', action='store_true')
parser.add_argument('--save', default='1', type=str, help='saving prefix')
parser.add_argument('--load', default='', type=str, help='loading prefix')
parser.add_argument('--lr', default=1e-4, type=float, help='learning rate')
parser.add_argument('--coeff', default=5e-1, type=float, help='coefficient of regularization')
parser.add_argument('--cot', default=0, type=float, help='coefficient of threshold regularization')
parser.add_argument('--thres', default=1.5, type=float, help='threshold multiplier')
parser.add_argument('--gp', default=10, type=float, help='coefficient of gp')
parser.add_argument('--std', default=0.3, type=float, help='std of Gaussian kernel')
parser.add_argument('--leak', default=0.2, type=float, help='leaky relu param')
parser.add_argument('--beta1', default=0, type=float, help='Adam param')
parser.add_argument('--beta2', default=0.9, type=float, help='Adam param')
parser.add_argument('--temp', default=1, type=float, help='Softmax temperature')
parser.add_argument('--ent', default=0, type=float, help='Entropy coefficient')
parser.add_argument('--prob', default=1, type=float, help='p of Bernoulli distribution')
parser.add_argument('--iter', default=400000, type=int, help='number of iterations')
parser.add_argument('--reg', default=1, type=int, help='period of regularization')
parser.add_argument('--batch-size', default=64, type=int, help='batchsize')
parser.add_argument('--image-size', default=64, type=int, help='image size')
parser.add_argument('--dim', default=64, type=int, help='feature channels')
parser.add_argument('--nlat', default=100, type=int, help='noise dimension')
parser.add_argument('--nparts', default=5, type=int, help='number of parts')
parser.add_argument('--radius', default=2, type=int, help='radius of Gaussian kernel')
parser.add_argument('--c-iters', default=5, type=int, help='number of critic iteration')
parser.add_argument('--printfreq', default=400, type=int, help='printing frequency')
parser.add_argument('--g-iters', default=1, type=int, help='number of generator iteration')

args = parser.parse_args()
print(args)

data_dir = os.path.join(args.root, "data")
log_dir = os.path.join(args.root, "log", args.save)
code_dir = os.path.join(args.root, "src")
check_dir = os.path.join(args.root, "checkpoints")
tensorboard_dir = os.path.join(args.root, "tensorboard_log", args.save)

# check the existence of data
if os.path.exists(data_dir) is False:
    print("The data path does not exist!")

# create the folder for log
if os.path.exists(log_dir) is False:
    os.makedirs(os.path.join(log_dir, 'visualization'))
else:
    if args.resume is False:
        shutil.rmtree(log_dir) 
        os.makedirs(os.path.join(log_dir, 'visualization'))

# create the folder for checkpoint
if os.path.exists(check_dir) is False:
    os.makedirs(check_dir)

# create the folder for dataset
if os.path.exists(data_dir) is False:
    os.makedirs(data_dir)

# create the folder for tensorboard writer
if os.path.exists(tensorboard_dir) is False:
    os.makedirs(tensorboard_dir)
else:
    if args.resume is False:
        shutil.rmtree(tensorboard_dir) 
        os.makedirs(tensorboard_dir)

# init the tensorboard writer
writer = SummaryWriter(tensorboard_dir)

# copy the code to the log folder
if (os.path.exists(code_dir) is False) or (args.resume is False):
    shutil.copytree(code_dir, os.path.join(log_dir, "src"))

# wrap up the convolution
def conv3x3(in_planes, out_planes, stride=1):
    """3x3 convolution with padding"""
    return nn.Conv2d(in_planes, out_planes, kernel_size=3, stride=stride,
                     padding=1, bias=False)

# Basicneck of standard ResNet18/34
class BasicBlock(nn.Module):
    expansion = 1

    def __init__(self, inplanes, planes, stride=1, downsample=None):
        super(BasicBlock, self).__init__()
        self.conv1 = conv3x3(inplanes, planes, stride)
        self.bn1 = nn.BatchNorm2d(planes)
        self.relu = nn.ReLU(inplace=True)
        self.conv2 = conv3x3(planes, planes)
        self.bn2 = nn.BatchNorm2d(planes)
        self.downsample = downsample
        self.stride = stride

    def forward(self, x):
        residual = x

        out = self.conv1(x)
        out = self.bn1(out)
        out = self.relu(out)

        out = self.conv2(out)
        out = self.bn2(out)

        if self.downsample is not None:
            residual = self.downsample(x)

        out += residual
        out = self.relu(out)

        return out

def generate_colors(num_colors):
    """
    Generate distinct value by sampling on hls domain.

    Parameters
    ----------
    num_colors: int
        Number of colors to generate.

    Returns
    ----------
    colors_np: np.array, [num_colors, 3]
        Numpy array with rows representing the colors.

    """
    colors=[]
    for i in np.arange(0., 360., 360. / num_colors):
        hue = i/360.
        lightness = 0.5
        saturation = 0.9
        colors.append(colorsys.hls_to_rgb(hue, lightness, saturation))

    colors_np = np.array(colors)*1.
        
    return colors_np


def plot_assignment(savepath, assign_hard, input):
    """
    Blend the original image and the colored assignment maps.

    Parameters
    ----------
    root: str
        Root path for saving visualization results.
    assign_hard: np.array, [H, W]
        Hard assignment map (int) denoting the deterministic assignment of each pixel. Generated via argmax.

    Returns
    ----------
    Save the result to root/assignment.png.

    """
    # generate the numpy array for colors
    colors = generate_colors(args.nparts)
    colors = torch.tensor(colors).float()

    # coefficient for blending
    coeff = 0.3

    # load the input as RGB image, convert into numpy array
    input = input.float()

    # blending by each pixel
    for k in range(assign_hard.shape[0]):
        for i in range(assign_hard.shape[1]):
            for j in range(assign_hard.shape[2]):
                assign_kij = assign_hard[k, i, j]
                input[k, :, i, j] = (1-coeff) * input[k, :, i, j] + coeff * colors[assign_kij]

    # save the resulting image
    utils.save_image(input, savepath)

def create_generator():
    mapping = nn.ModuleList()
    feat_mapping = nn.ModuleList()
    att_mapping = nn.ModuleList()
    post_feat = nn.ModuleList()
    post_att = nn.ModuleList()
    for i in range(args.nparts):
        # mapping.append(nn.Sequential(
        #     ConvTranspose2d(args.nlat, args.dim * 8, 4, 1, 0, bias=False), BatchNorm2d(args.dim * 8), ReLU(inplace=True),
        #     ConvTranspose2d(args.dim * 8, args.dim * 4, 4, 2, 1, bias=False), BatchNorm2d(args.dim * 4), ReLU(inplace=True),
        #     ConvTranspose2d(args.dim * 4, args.dim * 2, 4, 2, 1, bias=False), BatchNorm2d(args.dim * 2), ReLU(inplace=True),
        #     ConvTranspose2d(args.dim * 2, args.dim, 4, 2, 1, bias=False), BatchNorm2d(args.dim), ReLU(inplace=True),
        #     ))
        # feat_mapping.append(nn.Sequential(Conv2d(args.dim, args.dim, 5, stride=1, padding=2), BatchNorm2d(args.dim), ReLU(inplace=True),
        #     Conv2d(args.dim, args.dim, 5, stride=1, padding=2), BatchNorm2d(args.dim), ReLU(inplace=True)))
        # att_mapping.append(nn.Sequential(Conv2d(args.dim, args.dim, 5, stride=1, padding=2), BatchNorm2d(args.dim), ReLU(inplace=True),
        #     Conv2d(args.dim, 1, 5, stride=1, padding=2)))
        if args.complex is True:
            feat_mapping.append(nn.Sequential(
                ConvTranspose2d(args.nlat, args.dim * 8, 4, 1, 0, bias=False), BatchNorm2d(args.dim * 8), ReLU(inplace=True),
                ConvTranspose2d(args.dim * 8, args.dim * 4, 4, 2, 1, bias=False), BatchNorm2d(args.dim * 4), ReLU(inplace=True),
                ConvTranspose2d(args.dim * 4, args.dim * 2, 4, 2, 1, bias=False), BatchNorm2d(args.dim * 2), ReLU(inplace=True),
                ConvTranspose2d(args.dim * 2, args.dim, 4, 2, 1, bias=False), BatchNorm2d(args.dim), ReLU(inplace=True),
                ))
            att_mapping.append(nn.Sequential(
                ConvTranspose2d(args.nlat, args.dim * 8, 4, 1, 0, bias=False), BatchNorm2d(args.dim * 8), ReLU(inplace=True),
                nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 8, args.dim * 4, 5, stride=1, padding=2), BatchNorm2d(args.dim * 4), ReLU(inplace=True),
                nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 4, args.dim * 2, 5, stride=1, padding=2), BatchNorm2d(args.dim * 2), ReLU(inplace=True),
                nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 2, args.dim * 1, 5, stride=1, padding=2), BatchNorm2d(args.dim * 1), ReLU(inplace=True),
                Conv2d(args.dim, 1, 5, stride=1, padding=2)))
            img_mapping = nn.Sequential(ConvTranspose2d(args.dim, 3, 4, 2, 1, bias=False), Tanh())
        else:
            feat_mapping.append(nn.Sequential(
                ConvTranspose2d(args.nlat, args.dim * 8, 4, 1, 0, bias=False), BatchNorm2d(args.dim * 8), ReLU(inplace=True),
                ConvTranspose2d(args.dim * 8, args.dim * 4, 4, 2, 1, bias=False), BatchNorm2d(args.dim * 4), ReLU(inplace=True),
                ConvTranspose2d(args.dim * 4, args.dim * 2, 4, 2, 1, bias=False), BatchNorm2d(args.dim * 2), ReLU(inplace=True),
                ConvTranspose2d(args.dim * 2, args.dim, 4, 2, 1, bias=False), BatchNorm2d(args.dim), ReLU(inplace=True),
                ))
            att_mapping.append(nn.Sequential(
                ConvTranspose2d(args.nlat, args.dim * 8, 4, 1, 0, bias=False), BatchNorm2d(args.dim * 8), ReLU(inplace=True),
                nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 8, args.dim * 4, 5, stride=1, padding=2), BatchNorm2d(args.dim * 4), ReLU(inplace=True),
                nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 4, args.dim * 2, 5, stride=1, padding=2), BatchNorm2d(args.dim * 2), ReLU(inplace=True),
                nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 2, args.dim * 1, 5, stride=1, padding=2), BatchNorm2d(args.dim * 1), ReLU(inplace=True),
                Conv2d(args.dim, 1, 5, stride=1, padding=2)))
            img_mapping = nn.Sequential(ConvTranspose2d(args.dim, 3, 4, 2, 1, bias=False), Tanh())
    return DeterministicConditional(mapping, feat_mapping, att_mapping, img_mapping, num_parts=args.nparts)

def create_critic():
    if args.complex is True:
        z_mapping = nn.Sequential(Conv2d(args.dim * 8, args.dim * 8, 4, 1, 0), LeakyReLU(args.leak), Conv2d(args.dim * 8, args.nlat * args.nparts, 1))
        x_mapping = nn.Sequential(Conv2d(args.dim * 8, args.dim * 8, 4, 1, 0), LeakyReLU(args.leak))
        joint_mapping = nn.Sequential(
            Conv2d(3, args.dim, 4, 2, 1), LeakyReLU(args.leak),
            Conv2d(args.dim, args.dim * 2, 4, 2, 1), LeakyReLU(args.leak),
            Conv2d(args.dim * 2, args.dim * 4, 4, 2, 1), LeakyReLU(args.leak),
            Conv2d(args.dim * 4, args.dim * 8, 4, 2, 1), LeakyReLU(args.leak)
            )
        return JointCritic(x_mapping, joint_mapping, z_mapping)
    else:
        x_mapping = nn.Sequential(
            Conv2d(3, args.dim, 4, 2, 1), LeakyReLU(args.leak),
            Conv2d(args.dim, args.dim * 2, 4, 2, 1), LeakyReLU(args.leak),
            Conv2d(args.dim * 2, args.dim * 4, 4, 2, 1), LeakyReLU(args.leak),
            Conv2d(args.dim * 4, args.dim * 8, 4, 2, 1), LeakyReLU(args.leak),
            Conv2d(args.dim * 8, args.dim * 8, 4, 1, 0), LeakyReLU(args.leak))
        return JointCritic(x_mapping, None, None)


def create_WALI():
    G = create_generator()
    C = create_critic()
    wali = WALI(G, C, args)
    return wali


def main():
    # create the model
    wali = create_WALI().cuda()
    #wali = nn.DataParallel(wali)

    # define the optimizer
    optimizerG = Adam(wali.get_generator_parameters(), 
        lr=args.lr, betas=(args.beta1, args.beta2))
    optimizerC = Adam(wali.get_critic_parameters(),
        lr=args.lr, betas=(args.beta1, args.beta2))
    if args.complex:
        import itertools
        optimizerI = Adam(itertools.chain(wali.get_generator_parameters(), wali.get_critic_parameters()),
            lr=args.lr, betas=(args.beta1, args.beta2))

    # init the iter status
    curr_iter = C_iter = G_iter = 0
    C_update, G_update = True, False
    # args.resume = True
    # optionally load the model
    if args.resume:
        resume_dir = os.path.join(check_dir, args.save+'_latest.pth.tar')
        if os.path.isfile(resume_dir):
            print("Loading checkpoint...")
            checkpoint = torch.load(resume_dir)
            curr_iter = checkpoint['curr_iter']
            C_iter = checkpoint['C_iter']
            G_iter = checkpoint['G_iter']
            C_update = checkpoint['C_update']
            G_update = checkpoint['G_update']
            optimizerG.load_state_dict(checkpoint['optimizerG'])
            optimizerC.load_state_dict(checkpoint['optimizerC'])
            if args.complex:
                optimizerI.load_state_dict(checkpoint['optimizerI'])
            wali.load_state_dict(checkpoint['state_dict'])
        
        elif args.load != '':
            resume_dir = os.path.join(check_dir, args.load+'_latest.pth.tar')
            if os.path.isfile(resume_dir):
                print("Loading model params...")
                checkpoint = torch.load(resume_dir)
                wali.load_state_dict(checkpoint['state_dict'])
            else:
                print(hhh)
        
        else:
            print('No checkpoints or loading models found!')


    # define the data transform and loader
    transform = transforms.Compose([
        transforms.Resize(args.image_size), 
        transforms.CenterCrop(args.image_size), 
        transforms.ToTensor(),
        transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
    celeba = datasets.ImageFolder(data_dir, transform=transform)
    loader = data.DataLoader(celeba, args.batch_size, shuffle=True, num_workers=6)
    num_iters = len(loader)
    # define the noise vector for generating images
    noise = torch.randn(64, args.nparts, args.nlat, 1, 1).cuda()


    print('Training starts...')

    while curr_iter < args.iter:
        for batch_idx, (x, _) in enumerate(loader, 1):

            # copy into gpu if possible
            x = x.cuda()

            # the first iteration
            if curr_iter == 0:
                init_x = x
                curr_iter += 1
            
            # sample z and forward the generator & criticizer to get the loss
            z = torch.randn(x.size(0), args.nparts, args.nlat, 1, 1).cuda()
            if args.complex:
                C_loss, G_loss, att_loss, regress_loss = wali(x, z, lamb=args.gp)
            else:
                C_loss, G_loss, att_loss = wali(x, z, lamb=args.gp)
            if args.reg != 1:
                if curr_iter >= args.reg:#% args.reg == 0:
                    current_coeff = [1, 1]
                else:
                    current_coeff = [1, 0]
            else:
                current_coeff = [1, 1]
            Gen_loss = current_coeff[0] * G_loss + current_coeff[1] * att_loss
            
            # update C for args.c_iters steps
            if C_update:
                optimizerC.zero_grad()
                if args.complex:
                    C_loss.backward(retain_graph=True)
                else:
                    C_loss.backward()
                writer.add_scalar('data/C_loss', C_loss.item(), (curr_iter-1) * args.c_iters + C_iter)
                optimizerC.step()
                C_iter += 1

                if C_iter == args.c_iters:
                    C_iter = 0
                    C_update, G_update = False, True
                continue
            
            # # update G for args.g_iters steps
            if G_update:
                optimizerG.zero_grad()
                if args.complex:
                    Gen_loss.backward(retain_graph=True)
                else:
                    Gen_loss.backward()
                writer.add_scalar('data/G_loss', G_loss.item(), (curr_iter-1) * args.g_iters + G_iter)
                writer.add_scalar('data/att_loss', att_loss.item(), (curr_iter-1) * args.g_iters + G_iter)
                optimizerG.step()
                G_iter += 1

                if G_iter == args.g_iters:
                    G_iter = 0
                    C_update, G_update = True, False
                    curr_iter += 1
                else:
                    continue
            if args.complex:
                optimizerI.zero_grad()
                regress_loss.backward()
                writer.add_scalar('data/regress_loss', regress_loss.item(), curr_iter-1)
                optimizerI.step()
                current_state = {
                        'curr_iter': curr_iter,
                        'state_dict': wali.state_dict(),
                        'optimizerG': optimizerG.state_dict(),
                        'optimizerC': optimizerC.state_dict(),
                        'optimizerI': optimizerI.state_dict(),
                        'C_iter': C_iter,
                        'G_iter': G_iter,
                        'C_update': C_update,
                        'G_update': G_update,
                    }
            else:
                current_state = {
                        'curr_iter': curr_iter,
                        'state_dict': wali.state_dict(),
                        'optimizerG': optimizerG.state_dict(),
                        'optimizerC': optimizerC.state_dict(),
                        'C_iter': C_iter,
                        'G_iter': G_iter,
                        'C_update': C_update,
                        'G_update': G_update,
                    }

            # print training statistics
            if curr_iter % args.printfreq == 0:
                print('[%d/%d]\tW-distance: %.4f\tC-loss: %.4f\tatt-loss: %.4f'
                    % (curr_iter, args.iter, G_loss.item(), C_loss.item(), att_loss.item()), flush=True)

                # plot reconstructed images and samples
                wali.eval()
                genr_imgs = wali.generate(noise)
                genr_inputs = genr_imgs[0].detach_().cpu()
                genr_atts = genr_imgs[1][:, 0:1].clone().contiguous().detach_().cpu()
                #print(genr_atts.shape, genr_inputs.shape)
                assign_reshaped = torch.nn.functional.interpolate(genr_imgs[1].data.cpu(), size=(args.image_size, args.image_size), mode='bilinear', align_corners=False)
                # generate the one-channel hard assignment via argmax
                _, assign = torch.max(assign_reshaped, 1) 
                # colorize and save the assignment
                current_inputs = genr_inputs * 0.5 + 0.5
                utils.save_image(current_inputs, os.path.join(log_dir, 'visualization', str(curr_iter)+'_img.png'))
                plot_assignment(os.path.join(log_dir, 'visualization', str(curr_iter)+'_ass.png'), assign.cpu(), current_inputs)
                utils.save_image(genr_atts, os.path.join(log_dir, 'visualization', str(curr_iter)+'_att.png'))
                wali.train()
                torch.save(current_state, os.path.join(check_dir, args.save+'_latest.pth.tar'))
            
            # save model
            if curr_iter % (args.iter // 10) == 0:
                torch.save(current_state, os.path.join(check_dir, args.save+str(curr_iter)+'.pth.tar'))
            
    writer.close()


if __name__ == "__main__":
    main()
