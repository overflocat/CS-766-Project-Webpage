# system lib
import argparse
import os
import shutil
import time
import random
import pdb
import numpy as np
from scipy.stats import beta

# pytorch lib
import torch
import torch.nn as nn
import torch.nn.parallel
import torch.backends.cudnn as cudnn
import torch.optim
import torch.utils.data
import torchvision.transforms as transforms
import torchvision.datasets as datasets
import torchvision.models as models
import torch.nn.functional as F
from torch.autograd import Function

def GaussianKernel(radius, std):
    """
    Generate a gaussian blur kernel based on the given radius and std.

    Args
    ----------
    radius: int
        Radius of the Gaussian kernel. Center not included.
    std: float
        Standard deviation of the Gaussian kernel.

    Returns
    ----------
    weight: torch.FloatTensor, [2 * radius + 1, 2 * radius + 1]
        Output Gaussian kernel.

    """
    size = 2 * radius + 1
    weight = torch.ones(size, size)
    weight.requires_grad = False
    for i in range(-radius, radius+1):
        for j in range(-radius, radius+1):
            dis = (i * i) + (j * j)
            weight[i+radius][j+radius] =  np.exp(-dis / (2 * std * std))
    weight = weight / weight.sum()
    return weight

def ShapingLoss(assign, radius, std, num_parts, params):
    """
    Wasserstein shaping loss for Bernoulli distribution.

    Args
    ----------
    assign: torch.cuda.FloatTensor, [batch_size, num_parts, height, width]
        Assignment map for grouping.
    radius: int
        Radius for the Gaussian kernel. 
    std: float
        Standard deviation for the Gaussian kernel.
    num_parts: int
        Number of object parts in the current model.
    p: float
        Parameter of Bernoulli distribution.

    Returns
    ----------
    loss: torch.cuda.FloatTensor, [1, ]
        Average Wasserstein shaping loss for the current minibatch.
        
    """

    p, reparam = params
    batch_size = assign.shape[0]

    # Gaussian blur
    if radius == 0:
        assign_smooth = assign
    else:
        weight = GaussianKernel(radius, std)
        weight = weight.contiguous().view(1, 1, 2*radius+1, 2*radius+1).expand(num_parts, 1, 2*radius+1, 2*radius+1).cuda()
        assign_smooth = torch.nn.functional.conv2d(assign, weight, groups=num_parts)

    # pool the assignment maps into [batch_size, num_parts] and sort along the first ascendingly
    assign_loss = torch.nn.functional.adaptive_max_pool2d(assign_smooth, (1,1)).squeeze(2).squeeze(2)
    assign_indicator, _ = assign_loss.sort(dim=0, descending=False)
    

    # generate the samples for prior according to the parameter p
    num_ones = int(p * batch_size)
    num_zeros = batch_size - num_ones
    if p != 0 and p != 1:
        subtract_matrix_zeros = torch.zeros(num_zeros, assign_indicator.shape[1]).cuda()
        subtract_matrix_ones = torch.ones(num_ones, assign_indicator.shape[1]).cuda()
        subtract_term = torch.cat([subtract_matrix_zeros, subtract_matrix_ones], dim=0)
    elif p == 0:
        subtract_term = torch.zeros(batch_size, assign_indicator.shape[1]).cuda()
    else:
        subtract_term = torch.ones(batch_size, assign_indicator.shape[1]).cuda()

    # reparameterize the distribution if specified
    if reparam == True:
        assign_indicator = (assign_indicator + 1e-5).log()
        subtract_term = (subtract_term + 1e-5).log()

    # calculate the loss
    output_nk = (subtract_term - assign_indicator).abs()
    loss = output_nk.mean()

    #     # calculate the loss
    #     output_nk = (subtract_term - assign_indicator).abs()
    #     loss = output_nk.mean()
    # else:

    #     # calculate the loss
    #     output_nk = (subtract_term - assign_indicator).abs()
    #     output_k = torch.mean(output_nk, dim=0)
    #     loss = -(1 - output_k + 1e-5).log().mean()

    return loss

def ShapingLoss_thres(assign, radius, std, num_parts, thres):
    """
    Wasserstein shaping loss for Bernoulli distribution.

    Args
    ----------
    assign: torch.cuda.FloatTensor, [batch_size, num_parts, height, width]
        Assignment map for grouping.
    radius: int
        Radius for the Gaussian kernel. 
    std: float
        Standard deviation for the Gaussian kernel.
    num_parts: int
        Number of object parts in the current model.
    p: float
        Parameter of Bernoulli distribution.

    Returns
    ----------
    loss: torch.cuda.FloatTensor, [1, ]
        Average Wasserstein shaping loss for the current minibatch.
        
    """
    batch_size = assign.shape[0]

    # Gaussian blur
    if radius == 0:
        assign_smooth = assign
    else:
        weight = GaussianKernel(radius, std)
        weight = weight.contiguous().view(1, 1, 2*radius+1, 2*radius+1).expand(num_parts, 1, 2*radius+1, 2*radius+1).cuda()
        assign_smooth = torch.nn.functional.conv2d(assign, weight, groups=num_parts)

    # thresholding the assignment and zeroing the low values
    assign_truc = torch.nn.functional.threshold(assign_smooth, thres/float(num_parts), 0, inplace=False)
    loss = 1 - assign_truc.mean()

    return loss

# att should be N * K * H * W
def Entropy(att):
    att_log = torch.log(att + 1e-10)
    plogp = att * att_log
    entropy_nhw = torch.sum(-plogp, dim=1)
    entropy = entropy_nhw.mean()
    return entropy
