import argparse, torch
from torchvision import utils
from torch.nn import Conv2d, ConvTranspose2d, BatchNorm2d, LeakyReLU, ReLU, Tanh
import torch.nn as nn
from util import DeterministicConditional, JointCritic, WALI
import os

NLAT = 100
IMAGE_SIZE = 64
NUM_CHANNELS = 3

# arguments
parser = argparse.ArgumentParser(description='Training config')
parser.add_argument('--load', default='', type=str, help='loading prefix')
parser.add_argument('--leak', default=0.2, type=float, help='leaky relu param')
parser.add_argument('--batch-size', default=64, type=int, help='batchsize')
parser.add_argument('--image-size', default=64, type=int, help='image size')
parser.add_argument('--nlat', default=100, type=int, help='noise dimension')
parser.add_argument('--dim', default=64, type=int, help='feature channels')
parser.add_argument('--nparts', default=5, type=int, help='number of parts')

args = parser.parse_args()
check_dir = "../checkpoints"
def create_generator():
    mapping = nn.ModuleList()
    feat_mapping = nn.ModuleList()
    att_mapping = nn.ModuleList()
    post_feat = nn.ModuleList()
    post_att = nn.ModuleList()
    for i in range(args.nparts):
        feat_mapping.append(nn.Sequential(
            ConvTranspose2d(args.nlat, args.dim * 8, 4, 1, 0, bias=False), BatchNorm2d(args.dim * 8), ReLU(inplace=True),
            ConvTranspose2d(args.dim * 8, args.dim * 4, 4, 2, 1, bias=False), BatchNorm2d(args.dim * 4), ReLU(inplace=True),
            ConvTranspose2d(args.dim * 4, args.dim * 2, 4, 2, 1, bias=False), BatchNorm2d(args.dim * 2), ReLU(inplace=True),
            ConvTranspose2d(args.dim * 2, args.dim, 4, 2, 1, bias=False), BatchNorm2d(args.dim), ReLU(inplace=True),
            ))
        att_mapping.append(nn.Sequential(
            ConvTranspose2d(args.nlat, args.dim * 8, 4, 1, 0, bias=False), BatchNorm2d(args.dim * 8), ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 8, args.dim * 4, 5, stride=1, padding=2), BatchNorm2d(args.dim * 4), ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 4, args.dim * 2, 5, stride=1, padding=2), BatchNorm2d(args.dim * 2), ReLU(inplace=True),
            nn.Upsample(scale_factor=2, mode='bilinear', align_corners=None), Conv2d(args.dim * 2, args.dim * 1, 5, stride=1, padding=2), BatchNorm2d(args.dim * 1), ReLU(inplace=True),
            Conv2d(args.dim, 1, 5, stride=1, padding=2)))
        img_mapping = nn.Sequential(ConvTranspose2d(args.dim, 3, 4, 2, 1, bias=False), Tanh())
    return DeterministicConditional(mapping, feat_mapping, att_mapping, img_mapping, num_parts=args.nparts)

def create_critic():
    x_mapping = nn.Sequential(
        Conv2d(3, args.dim, 4, 2, 1), LeakyReLU(args.leak),
        Conv2d(args.dim, args.dim * 2, 4, 2, 1), LeakyReLU(args.leak),
        Conv2d(args.dim * 2, args.dim * 4, 4, 2, 1), LeakyReLU(args.leak),
        Conv2d(args.dim * 4, args.dim * 8, 4, 2, 1), LeakyReLU(args.leak),
        Conv2d(args.dim * 8, args.dim * 8, 4, 1, 0), LeakyReLU(args.leak))

    return JointCritic(x_mapping)


def create_WALI():
    G = create_generator()
    C = create_critic()
    wali = WALI(G, C, args)
    return wali

def interpolate(generator, z0, z1, nintp=10, filepath=None):
    """ Interpolate in the latent space.

    Args:
        generator: Generator network that takes z as input.
        z0: Where interpolation starts.
        z1: Where interpolation ends.
        nintp: Number of intermediate steps.
        path: Trajectory of interpolation. Default: linear
        filepath: Where to save the images.
    """
    assert z1.size() == z1.size()
    z0, z1 = z0.view(z0.size(0), args.nparts, NLAT, 1, 1), z1.view(z1.size(0), args.nparts, NLAT, 1, 1)
    alphas = torch.linspace(0, 1, nintp)
    imgs = []
    atts = []

    for k in range(args.nparts):
        imgs = []
        atts = []
        for alpha in alphas:
            #z_noise = torch.randn(args.batch_size, NLAT, 1, 1).cuda()
            z = z0.clone().data
            z[:, k] = z[:, k] * alpha + z1[:, k] * (1 - alpha)
            img = generator(z)[0].detach_() * 0.5 + 0.5
            att = generator(z)[1][:, k].clone().unsqueeze(1).contiguous().detach()
            imgs.append(img.cpu())
            atts.append(att.cpu())
        imgs = torch.cat(imgs, dim=1).view(-1, NUM_CHANNELS, IMAGE_SIZE, IMAGE_SIZE)
        atts = torch.cat(atts, dim=1).view(-1, 1, 32, 32)
        grid = utils.make_grid(imgs, nrow=nintp)
        grid_ = utils.make_grid(atts, nrow=nintp)
        utils.save_image(grid, filepath+'_'+str(k)+'.png')
        utils.save_image(grid_, filepath+'_'+str(k)+'_att.png')

    print('Interpolated images saved.')


def main():
    wali = create_WALI().cuda()
    resume_dir = os.path.join(check_dir, args.load+'_latest.pth.tar')
    if os.path.isfile(resume_dir):
        print("Loading model params...")
        checkpoint = torch.load(resume_dir)
        wali.load_state_dict(checkpoint['state_dict'])
    else:
        print(hhh)
    generator = wali.G

    z0 = torch.randn(args.batch_size, args.nparts, NLAT, 1, 1).cuda()
    z1 = torch.randn(args.batch_size, args.nparts, NLAT, 1, 1).cuda()
    interpolate(generator, z0, z1, nintp=10, filepath='../results/'+args.load)



if __name__ == "__main__":
    main()
