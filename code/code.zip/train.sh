#!/bin/bash
#SBATCH --gres=gpu:1
#SBATCH -o log/train_out/283.txt
#SBATCH --job-name=283
#SBATCH -t 0-23:00 # time (D-HH:MM)--load 174 
cd src
python train.py --save 283 --coeff 0 --ent 0 --cot 0 --temp 1e-7 --thres 1 --lr 1e-4 --batch-size 240 --c-iters 5 --nlat 100 --leak 0.2 --gp 10 --image-size 64 --beta1 0.5 --beta2 0.9 --nparts 2 --prob 1 --radius 3 --std 1 --reg 1 --printfreq 400 --resume --complex