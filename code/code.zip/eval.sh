#!/bin/bash
#SBATCH --gres=gpu:1 -p wacc
#SBATCH -o log/eval_out.txt
#SBATCH --job-name=eval
#SBATCH -t 0-1:00 # time (D-HH:MM)--load 174 
cd src
python interpolate.py --load 243 --batch-size 5 --nlat 100 --leak 0.2 --image-size 64 --nparts 2